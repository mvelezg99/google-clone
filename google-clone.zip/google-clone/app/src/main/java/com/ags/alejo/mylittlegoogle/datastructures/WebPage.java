package com.ags.alejo.mylittlegoogle.datastructures;

import java.util.List;

/**
 * @author Alejandro Garcia Serna,Miguel Angel Velez
 */
public class WebPage implements Comparable<WebPage>{
    
    private String keyword;
    private List< String > urls;

    public WebPage(String keyword, List<String> urls) {
        this.keyword = keyword;
        this.urls = urls;
    }

    public WebPage(String keyword) {
        this.keyword = keyword;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public List<String> getUrls() {
        return urls;
    }

    public void setUrls(List<String> urls) {
        this.urls = urls;
    }


    /**
     * Método que sobrescribe el compareTo heredado de Object, para comparar según nuestros criterios
     * @param o
     * @return 1 si es mayor; -1 si es menor
     */
    @Override
    public int compareTo(WebPage o) {
        if(o.keyword.compareTo(keyword) > 0){
            return 1;
        }else if(o.keyword.compareTo(keyword) < 0){
            return -1;
        } else {
            return 0;
        }
    }
}
