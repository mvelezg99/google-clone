package com.ags.alejo.mylittlegoogle.datastructures;

import java.util.List;

/**
 *
 * @author Alejandro Garcia Serna,Miguel Angel Velez
 * @param <T>
 */
public class BinaryTree< T extends Comparable< T > > {
    
    Node< T > root;
    
    private class Node< E extends Comparable< E > > {
        
        E item;
        Node< E > left;
        Node< E > right;
        
        public Node(E item,Node left,Node right) {
            this.item = item;
            this.left = left;
            this.right = right;
        }

        public E getItem() {
            return item;
        }

        public void setItem(E item) {
            this.item = item;
        }

        public Node<E> getLeft() {
            return left;
        }

        public void setLeft(Node<E> left) {
            this.left = left;
        }

        public Node<E> getRight() {
            return right;
        }

        public void setRight(Node<E> right) {
            this.right = right;
        }
        
        
        
    }
    
    /**
     * Agrega un item al arbol binario
     * @param item
     * @return BinaryTree< T >
     */
    public void insert(T item) {
        Node<T> newNode = new Node(item,null,null);
        if(root == null) {
            root = newNode;
        } else {
            Node<T> parent = null;
            Node<T> current = root;
            while(true) {
                parent = current;
                if(item.compareTo(current.item) < 0) {
                    current = current.left;
                    if(current == null) {
                        parent.left = newNode;
                        break;
                    }
                } else {
                    current = current.right;
                    if(current == null) {
                        parent.right = newNode;
                        break;
                    }
                }
            }
        }
    }


    public T find(T itemToFind) {
        Node<T> current = root;
        while(itemToFind.compareTo(current.item) != 0) {
            if(itemToFind.compareTo(current.item) < 0) {
                current = current.left;
            } else {
                current = current.right;
            }
            if(current == null) {
                return null;
            }
        }
        return current.item;
    }


    
    /**
     * Verifica si el item del nodo actual es mayor que el item pasado por parametro para saber en que direccion dirigir el arbol
     * @param curreNode
     * @param item
     * @return 
     */
    private boolean isGreatherThan(T curreNode,T item) { return curreNode.compareTo(item) >= 1; }
    
    /**
     * Verifica si el item del nodo actual es menor que el item pasado por parametro para saber en que direccion dirigir el arbol
     * @param curreNode
     * @param item
     * @return 
     */
    private boolean isLessThan(T curreNode,T item) { return curreNode.compareTo(item) <= -1; }
    
    /**
     * Verifica si el arbol esta vacio
     * @return 
     */
    private boolean isEmpty() { return root == null; }

    public String preorder() {
        return preorder(root, 0);
    }

    private String preorder(Node<T> node, int c) {
        String t = "";
        for(int i = 0; i < c; i++) {
            t += "---";
        }
        t += (node != null ? node.item : "") + "\n";
        if(node == null || node.left == null && node.right == null) return t;
        t = t + preorder( node.left, c+1 );
        t = t + preorder( node.right, c+1 );
        return t;
    }
    
}
