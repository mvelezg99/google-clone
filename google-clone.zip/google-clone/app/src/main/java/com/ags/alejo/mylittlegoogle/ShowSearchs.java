package com.ags.alejo.mylittlegoogle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ags.alejo.mylittlegoogle.datastructures.BinaryTree;
import com.ags.alejo.mylittlegoogle.datastructures.WebPage;

import java.util.List;

public class ShowSearchs extends AppCompatActivity {

    private TextView tvSearch;
    private ListView lvSearch;

    private String wordSearch;
    private BinaryTree<WebPage> binTree;
    private List<String> urlSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_searchs);
        connect();
        wordSearch = MainActivity.search;
        searchOnTree(wordSearch);
    }

    private void connect(){
        tvSearch = findViewById(R.id.tvSearch);
        lvSearch = findViewById(R.id.lvSearch);
    }

    private void searchOnTree(String keyword){

        binTree = MainActivity.binaryTree;
        WebPage webSearch = new WebPage(keyword);

        long t1 = System.currentTimeMillis();
        webSearch = binTree.find(webSearch);
        long t2 = (System.currentTimeMillis()-t1)*1000;

        urlSearch = webSearch.getUrls();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_selectable_list_item,urlSearch);
        lvSearch.setAdapter(adapter);

        tvSearch.setText("Se encontraron "+urlSearch.size()+" resultados ("+t2+" s): ");



    }
}
